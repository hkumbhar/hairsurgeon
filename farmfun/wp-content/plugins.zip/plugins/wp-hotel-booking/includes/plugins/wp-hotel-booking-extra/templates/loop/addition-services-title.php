<tr class="hb_addition_services_title" data-cart-id="<?php echo esc_attr( $cart_id ); ?>" style="background-color: #FFFFFF;">
	<td colspan="<?php echo ( $page === 'checkout') ? 6 : 7  ?>">
		<?php _e( 'Addition Services', 'wp-hotel-booking' ); ?>
	</td>
</tr>