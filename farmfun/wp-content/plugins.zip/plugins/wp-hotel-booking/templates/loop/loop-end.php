<?php
/**
 * Room Loop End
 *
 * @author        ThimPress
 * @package       wp-hotel-booking/templates
 * @version       1.1.4
 */

if ( !defined( 'ABSPATH' ) ) {
	exit();
}

?>
    </ul>
<?php wp_reset_postdata(); ?>