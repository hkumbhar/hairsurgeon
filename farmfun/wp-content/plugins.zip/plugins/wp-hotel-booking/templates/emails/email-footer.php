<?php
/**
 * @Author: ducnvtt
 * @Date  :   2016-04-14 10:34:16
 * @Last  Modified by:   ducnvtt
 * @Last  Modified time: 2016-04-15 16:42:42
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

?>

</td>
</tr>
</tbody>
</table>
</td>
</tr>
</table>
</body>
</html>